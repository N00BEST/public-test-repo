import React from 'react';

import App from './ReposContainer/components/App';

export default class ReposContainer extends React.Component {
  render() {
    return(
      <App {...this.props} />
    );
  }
}

