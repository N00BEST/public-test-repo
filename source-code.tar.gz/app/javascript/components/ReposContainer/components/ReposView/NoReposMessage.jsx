import React from 'react';

const NoReposMessage = () => (
  <div className="no-repos-message">
    You haven't added any GitHub repos yet.
  </div>
);

export default NoReposMessage;
