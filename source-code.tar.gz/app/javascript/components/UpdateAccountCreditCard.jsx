import React from 'react';

import App from './UpdateAccountCreditCard/components/App';

export default class UpdateAccountCreditCard extends React.Component {
  render() {
    return(
      <App {...this.props} />
    );
  }
}

