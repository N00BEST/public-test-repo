HighVoltage.configure do |config|
  config.routes = false
end
