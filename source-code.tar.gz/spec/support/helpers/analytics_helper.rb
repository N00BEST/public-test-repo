module AnalyticsHelper
  def analytics
    Analytics.backend
  end
end
